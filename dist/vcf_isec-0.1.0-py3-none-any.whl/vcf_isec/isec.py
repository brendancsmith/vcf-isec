## vcf_comparator.py
import tempfile
from pathlib import Path
from typing import List, NamedTuple

from pysam import bcftools
from pysam.utils import SamtoolsError

from vcf_isec.errors import FileFormatError, IntersectError
from vcf_isec.parser import Variant, parse_variants


class ISecOutput(NamedTuple):
    intersection: List[Variant]
    complement1: List[Variant]
    complement2: List[Variant]


class VCFIntersection:
    def __init__(
        self,
        file1_path: Path | str,
        file2_path: Path | str,
        prefix: Path | str | None = None,
    ) -> None:
        self.file1_path = self._check_file(file1_path)
        self.file2_path = self._check_file(file2_path)

        if prefix:
            self.prefix = Path(prefix)
            if self.prefix.is_file():
                raise FileFormatError(f"{self.prefix} is not a directory.")
        else:
            self.prefix = None

    def _check_file(self, file_path: Path | str) -> Path:
        """
        Checks if the given file path is valid and meets the required conditions.

        Args:
            file_path (Path | str): The path to the file to be checked.

        Returns:
            Path: The validated file path.

        Raises:
            FileNotFoundError: If the file does not exist.
            FileFormatError: If the file is not a valid file or has an unsupported file type.
        """

        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"{file_path} does not exist.")
        if not file_path.is_file():
            raise FileFormatError(f"{file_path} is not a file.")
        if file_path.suffix != ".vcf":
            raise FileFormatError(f"{file_path} is not a supported file type.")

        return file_path

    def compare_vcf(self) -> ISecOutput:
        """
        Compares two VCF files and returns a tuple containing lists of shared variants,
        unique variants in file1, and unique variants in file2.

        Returns:
            Tuple[List[str], List[str], List[str]]: shared variants, unique to file1, unique to file2
        """

        try:
            if self.prefix:
                self.prefix.mkdir(parents=True, exist_ok=True)
                results = self._compare_vcf(self.prefix)
            else:
                with tempfile.TemporaryDirectory() as tmpdirname:
                    results = self._compare_vcf(tmpdirname)

        except SamtoolsError as e:
            raise IntersectError(
                f"Error in pysam library bcftools.isec function"
            ) from e
        except OSError as e:
            raise FileFormatError(f"Error reading file: {e.filename}") from e

        return results

    def _compare_vcf(self, dirname: Path | str) -> ISecOutput:
        dirname = Path(dirname)

        intersection = []
        complement1 = []
        complement2 = []

        bcftools.isec(
            str(self.file1_path),
            str(self.file2_path),
            output_dir=dirname,
            nfiles=2,
            writedir=True,
        )

        intersection_path = dirname / "0000.vcf"
        complements1_path = dirname / "0001.vcf"
        complements2_path = dirname / "0002.vcf"

        intersection = list(parse_variants(intersection_path))
        complement1 = list(parse_variants(complements1_path))
        complement2 = list(parse_variants(complements2_path))

        return ISecOutput(intersection, complement1, complement2)
