import click

from vcf_isec.errors import ErrorHandler
from vcf_isec.isec import VCFIntersection


@click.command()
@click.option(
    "-p",
    "--path",
    type=click.Path(file_okay=False, dir_okay=True),
    default=None,
    help="Output directory",
)
@click.argument(
    "file1",
    type=click.Path(exists=True, file_okay=True, dir_okay=False, allow_dash=True),
    #help="Path to the first VCF file.",
)
@click.argument(
    "file2",
    type=click.Path(exists=True, file_okay=True, dir_okay=False, allow_dash=True),
    #help="Path to the second VCF file.",
)
def main(path, file1, file2):
    try:
        isec = VCFIntersection(file1, file2, path)
        shared, unique1, unique2 = isec.compare_vcf()

        print(f"Shared Variants: {len(shared)}")
        print(f"Unique to {file1.name}: {len(unique1)}")
        print(f"Unique to {file1.name}: {len(unique2)}")
    except KeyboardInterrupt:
        click.echo("Received termination signal. Exiting now!")
        click.Abort(1)
    except Exception as e:
        ErrorHandler().handle(e)
        click.Abort(1)


if __name__ == "__main__":
    main()
