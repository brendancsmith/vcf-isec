from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional, Tuple

import pysam


@dataclass
class Variant:
    rid: int
    chrom: str
    contig: str
    pos: int
    start: int
    stop: int
    rlen: int
    qual: Optional[int]
    id: Optional[str]
    ref: Optional[str]
    alleles: Optional[Tuple[str, ...]]
    alts: Optional[Tuple[str, ...]]


def parse_variants(vcf_path: Path | str) -> Iterable[Variant]:
    """
    Extracts variants from a VCF file using pysam.VariantFile.

    Args:
        vcf_path (str): Path to the VCF file.

    Returns:
        Iterable[str]: Iterable of variants.
    """

    with pysam.VariantFile(str(vcf_path), "r") as vcf:
        for record in vcf.fetch():
            yield Variant(
                record.rid,
                record.chrom,
                record.contig,
                record.pos,
                record.start,
                record.stop,
                record.rlen,
                record.qual,
                record.id,
                record.ref,
                record.alleles,
                record.alts,
            )
